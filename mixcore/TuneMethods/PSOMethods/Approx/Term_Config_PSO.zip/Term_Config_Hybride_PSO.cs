﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Fuzzy_system.Fuzzy_Abstract.conf;
using Fuzzy_system.Approx_Singletone.Hybride;
using Fuzzy_system.Fuzzy_Abstract.learn_algorithm.conf;

namespace Fuzzy_system.Approx_Singletone.learn_algorithm
{
    class Term_Config_Hybride_PSO : Term_Config_PSO, ILearnHybride
    {
        protected int count_toPost_and_Get=10;

        public a_Fuzzy_System TuneUpFuzzySystem(ApproxHybride Ocean, a_Fuzzy_System Approximate, ILearnAlgorithmConf conf)
        {
            count_iteration = ((Term_Config_PSO_Search_conf)conf).Количество_итераций;
            c1 = ((Term_Config_PSO_Search_conf)conf).Коэффициент_c1;
            c2 = ((Term_Config_PSO_Search_conf)conf).Коэффициент_c2;
            w = 1;
            count_particle = ((Term_Config_PSO_Search_conf)conf).Особей_в_популяции;

            a_Fuzzy_System result = Approximate;

            X = new Knowlege_base_ARules[count_particle];
            V = new Knowlege_base_ARules[count_particle];
            Pi = new Knowlege_base_ARules[count_particle];
            Pg = new Knowlege_base_ARules();
            Errors = new double[count_particle];
            OldErrors = new double[count_particle];
            rnd = new Random();

            preIterate(result);

            int counterIter = 0;
            for (int i = 0; i < count_iteration; i++)
            {
                OneIteration(result);
                counterIter++;
                if (counterIter == 10)
                {
                    Ocean.Store(X.ToList().GetRange(0, count_particle / 2), this.ToString());
                    List<Knowlege_base_ARules> tempRes = Ocean.Get(count_particle / 2, Fuzzy_Abstract.Hybride.FuzzyHybrideBase.goodness.best, Fuzzy_Abstract.Hybride.FuzzyHybrideBase.islandStrategy.All);
                    
                    int size = tempRes.Count+count_particle / 2<X.Count()?tempRes.Count+count_particle:X.Count();
                    for (int p = count_particle / 2; p<size; p++)
                    {X[p]=tempRes[0];
                        tempRes.RemoveAt(0);
                    }
                    
                    counterIter = 0;
                }

            }

            result.Rulles_Database_Set[0] = Pg;
            return result;
       
        }
    }
}
